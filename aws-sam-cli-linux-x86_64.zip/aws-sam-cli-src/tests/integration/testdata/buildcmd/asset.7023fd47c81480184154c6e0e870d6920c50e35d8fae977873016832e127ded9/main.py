def handler(event, context):
    return "Hello World"